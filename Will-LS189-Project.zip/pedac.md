Problem:
  General Requirements:
    - must use Express (Done)
    - must use Pug View Templates (Done)
    - must use PostgreSQL to store data (Done)
    - **cannot** use any additional npm packages
      - we do not use any additional npm packages that handle application specific requirements (Done)
  App Specific Requirements
    - **Must have two database tables** (Done, we have comments/posts)
      - two tables in a one to many or many:many (Done Posts one to many and comments one to many)
    - MUST provide CRUD capabilities for the data
      - `CREATE`, `READ`, `UPDATE`, and `DELETE` (CRUD is available for both posts and comments)
      - When we delete a row from the table
        - delete on cascade  (Done)
      - do not provide crud capabilities for user table (Done)
    - must have all changes reflect immedielty in app and database (Done)
    - limit the amount of output per a page to a maximum item count of 5 - 10 (Done)
      - pagimenataiton 
      - (need to look how this works)
    - Unlike the LS App, your project should validate the page number and issue an appropriate error message if the URL is given with an invalid page number.
      - I don't understand this  (Done, if the page number is invalid, we route the user to the error message page view)
    - Items must be sorted consistently  (all items are sorted by date then time, timestamp tz)
      - aplahbetiicaly, numerically, etc
    - Display flash error messages (Done, all flash messages are displayed)
      - validate/sitize all input data as needed (Done, express validator santizes everything.)
      - Do not rely on html or javascript validation that executes in browser (Done)
      - display appropiate error flash message (Done)
        - if multiple erros are made, display multiple messages (Done)
      - Data that is not invliad, should not be cleared (Done)
    - Must require login authentication for all users (Done)


What am I going to make



A forum

Tables

Users
  - id
    - serial
  - username
    - text
  - password
    - text
  - type
    - admin or user
    - default user
  - status
    - active or banned
    - default active

Posts
  - id
    - serial
  - name
    - text
  - date
    - now default to current date
  - user_id
    - foreign_key references users

Comments
  - id
  - date
    - now default to current date
  - body
    - text
  - user_id
    - foreign key references user_id
  - post_id
    - foreign key references post_id

//maybe add it later
likes
  - id
  - user_id
  - comment_id


the / should redirect to forum
default will display pagnation 10 forum posts
so it should be forum/1

